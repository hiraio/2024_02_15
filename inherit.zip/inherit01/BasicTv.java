package edu.java.inherit01;

public class BasicTv {
	// 멤버 변수(필드, 프로피터)
	boolean powerOn;
	public int channel;
	public int volume;
	

	// 생성자
	public BasicTv() {}
	
	// 메소드
	public void turnOnOff() {
		System.out.println("turnOnoff() 메소드");
		

	}
} // end BasicTv

