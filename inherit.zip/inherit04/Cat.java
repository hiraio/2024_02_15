package edu.java.inherit04;

public class Cat extends Animal {
	
	@Override
	public void speak() {
		System.out.println("야옹");
	}

} 
