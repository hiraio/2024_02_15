package edu.java.inherit05;
public class Point {
	private double x;
	private double y;
//1. Point 클래스 생성
// - 멤버 변수(double x, double y)
// - 기본 생성자
// - 매개변수 생성자
// - toString()을 오버라이드하여 (x, y)형식의 문자열을 리턴하는 메소드 생성

	public Point() {}
	
	public Point(double x , double y) {
		
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return "(" + x + "," + y + ")";
	}
	

}
